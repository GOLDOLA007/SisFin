﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dados
{
    class MeioPagamento
    {
        public enum Pagamento {PIX = 1,  BOLETO = 2, CARTAO_DE_CREDITO = 3, CARTAO_DE_DEBITO = 4, DINHEIRO = 5  };
    }
}
