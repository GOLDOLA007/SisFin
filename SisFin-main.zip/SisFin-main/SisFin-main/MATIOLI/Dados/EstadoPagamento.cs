﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dados
{
    class EstadoPagamento
    {
        public enum EstadoPag {PENDENTE = 1, QUITADO = 2, CANCELADO = 0};
    }
}
